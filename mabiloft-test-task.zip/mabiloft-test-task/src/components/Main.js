import React from "react";

import Navbar from "./Navbar";
import Card from "./Card";

import DATA from "./Data";


function Main() {
    return (
        <>
            <Navbar />
            <div className="container">
                <br />
                <h2>
                    <b>Next on Mabitalks</b>
                </h2>
                <br />
                <button
                    type="button"
                    className="btn btn-light"
                    style={{
                        borderRadius: "20px",
                        backgroundColor: "#FCE9E2",
                        color: "#E85322",
                        borderColor: "#FCE9E2",
                        marginRight: "5px",
                    }}
                >
                    Design
                </button>
                <button
                    type="button"
                    className="btn btn-light"
                    style={{
                        borderRadius: "20px",
                        backgroundColor: "#FCE9E2",
                        color: "#E85322",
                        borderColor: "#FCE9E2",
                        marginRight: "5px",
                    }}
                >
                    Development
                </button>
                <button
                    type="button"
                    className="btn btn-light"
                    style={{
                        borderRadius: "20px",
                        backgroundColor: "#FCE9E2",
                        color: "#E85322",
                        borderColor: "#FCE9E2",
                        marginRight: "5px",
                    }}
                >
                    News
                </button>
                <button
                    type="button"
                    className="btn btn-light"
                    style={{
                        borderRadius: "20px",
                        backgroundColor: "#FCE9E2",
                        color: "#E85322",
                        borderColor: "#FCE9E2",
                        marginRight: "5px",
                    }}
                >
                    R&D
                </button>
                <button
                    type="button"
                    className="btn btn-light"
                    style={{
                        borderRadius: "20px",
                        backgroundColor: "#FCE9E2",
                        color: "#E85322",
                        borderColor: "#FCE9E2",
                        marginRight: "5px",
                    }}
                >
                    Presentation
                </button>
                <br />
                <br />

                <div className="row">
                    {DATA.map((card) => (
                        <Card key={card.id} card={card} tags={card.tags} />
                    ))}
                </div>
            </div>
        </>
    );

}

export default Main;