import React from "react";
import { BsHeart } from "react-icons/bs";

function Card(props) {
    return (
        <div className="col-12 col-lg-4 col-md-6">
            <div className="card" style={{ borderRadius: "20px" }}>
                <img
                    alt="card"
                    src={props.card.img}
                    className="card-img-top"
                    style={{ borderRadius: "10px" }}
                />
                <div className="card-body">
                    <div className="row">
                        <div className="col-10">
                            <h5 className="card-title">{props.card.title}</h5>
                        </div>
                        <div className="col-2">
                            <button
                                style={{
                                    backgroundColor: "white",
                                    borderColor: "white",
                                }}
                            >
                                <BsHeart />
                            </button>
                        </div>
                        <p className="card-text">{props.card.description}</p>
                    </div>
                </div>
            </div>
            <br />
        </div>
    );
}

export default Card;